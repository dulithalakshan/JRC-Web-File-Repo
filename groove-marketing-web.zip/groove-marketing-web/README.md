# groove-marketing-web

The **groove.com.au** website: plain HTML, CSS and JavaScript, deployed by GitHub Actions.

| Branch | Hosted on | Deploys | URL |
|---|---|---|---|
| `dev` (default) | Cloudflare Workers | automatically, on every push | `https://groove-marketing-web-dev.<subdomain>.workers.dev` (shown on each *Deploy dev* run) |
| `prod` | Azure App Service (Australia East) | manually, by IT Operations | `https://groove.com.au` after go-live |

## For developers

**`dev` is yours.** Every push to `dev` goes live on the dev site within a minute or two (watch the *Actions* tab; the run summary shows the URL).

1. Work on a branch off `dev` and open a PR back into `dev`. The **CI** check assembles the site, fails on broken image/font/CSS/JS paths, and smoke-tests it.
2. Merge. **Deploy dev** publishes it to Cloudflare automatically.
3. When dev is ready to go live, open a PR **from `dev` into `prod`** titled `Release: <what's in it>`. That PR is your sign-off.
4. IT Operations reviews and merges it, then runs **Deploy prod** by hand when they're ready.

You can't push or merge to `prod`, or run the prod deploy. That's intentional.

### How the site is published

Everything in the repo root (`index.html`, `css/`, `js/`, `assets/`, any new pages) is published as-is. `README.md`, `.github/`, `infra/`, `scripts/` and `docs/` never are.

- **Dev (Cloudflare):** served as static files. Every page carries `X-Robots-Tag: noindex` and `robots.txt` blocks all crawlers, so the dev site never shows up in Google. `/build-info.json` shows which commit is live.
- **Prod (Azure):** a tiny server (`.github/deploy/server.js`) serves the same files with gzip, cache and security headers. `/healthz` shows which commit is live.
- `/about` is served from `about.html` or `about/index.html`. Add a `404.html` for a custom not-found page.

On prod, images and fonts are cached for 7 days, so **give a changed image a new file name** (e.g. `hero-2026.jpg`) instead of overwriting it.

### Rules of the road

- Use **relative paths** for local files (`assets/logo/x.svg`, `css/styles.css`). CI fails the PR if a referenced file doesn't exist. Letter case matters.
- **No secrets in the repo.** The pitch form uses `mailto:`. If you ever need a form backend or API key, talk to IT first.
- Need a build step later (Vite, Astro, etc.)? Add a `package.json` with `npm run build`; ask IT to set the `SITE_DIR` repo variable to the build output folder (e.g. `dist`).

### Folders you shouldn't change without IT

`.github/`, `infra/`, `scripts/`, `docs/`. Changes there ride along in release PRs and IT will review them closely.

---

IT setup, release, rollback and go-live steps: [`docs/RUNBOOK.md`](docs/RUNBOOK.md).
