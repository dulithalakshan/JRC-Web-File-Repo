/* =========================================================
   Groove — interactions
   ========================================================= */
(function () {
  'use strict';

  var doc = document;
  var root = doc.documentElement;
  var body = doc.body;
  var reduceMotionQuery = window.matchMedia('(prefers-reduced-motion: reduce)');
  var reduceMotion = function () { return reduceMotionQuery.matches; };

  /* ---------- Footer year ---------- */
  var yearEl = doc.getElementById('year');
  if (yearEl) yearEl.textContent = String(new Date().getFullYear());

  /* ---------- Hero load sequence ---------- */
  (function heroIntro() {
    var img = doc.querySelector('.hero__img');
    var done = false;
    function start() {
      if (done) return;
      done = true;
      requestAnimationFrame(function () {
        requestAnimationFrame(function () { body.classList.add('is-loaded'); });
      });
    }
    if (!img || reduceMotion()) { start(); return; }
    if (img.complete && img.naturalWidth) {
      start();
    } else {
      img.addEventListener('load', start, { once: true });
      img.addEventListener('error', start, { once: true });
    }
    setTimeout(start, 1400); // never hold the page hostage to the image
  })();

  /* ---------- Sticky header ---------- */
  var header = doc.getElementById('siteHeader');
  var ticking = false;
  function onScrollHeader() {
    header.classList.toggle('is-scrolled', window.scrollY > 32);
    ticking = false;
  }
  window.addEventListener('scroll', function () {
    if (!ticking) { requestAnimationFrame(onScrollHeader); ticking = true; }
  }, { passive: true });
  onScrollHeader();

  /* ---------- Active nav link (scrollspy) ---------- */
  var navLinks = Array.prototype.slice.call(doc.querySelectorAll('.primary-nav a'));
  if ('IntersectionObserver' in window && navLinks.length) {
    var byId = {};
    navLinks.forEach(function (a) { byId[a.getAttribute('href').slice(1)] = a; });
    var spy = new IntersectionObserver(function (entries) {
      entries.forEach(function (entry) {
        var link = byId[entry.target.id];
        if (!link) return;
        if (entry.isIntersecting) {
          navLinks.forEach(function (l) { l.classList.remove('is-active'); l.removeAttribute('aria-current'); });
          link.classList.add('is-active');
          link.setAttribute('aria-current', 'true');
        }
      });
    }, { rootMargin: '-45% 0px -50% 0px' });
    Object.keys(byId).forEach(function (id) {
      var s = doc.getElementById(id);
      if (s) spy.observe(s);
    });
  }

  /* ---------- Mobile menu ---------- */
  (function mobileMenu() {
    var toggle = doc.getElementById('menuToggle');
    var menu = doc.getElementById('mobileMenu');
    if (!toggle || !menu) return;
    var open = false;

    function setOpen(next, returnFocus) {
      open = next;
      toggle.setAttribute('aria-expanded', String(open));
      toggle.setAttribute('aria-label', open ? 'Close menu' : 'Open menu');
      body.classList.toggle('menu-open', open);
      if (open) {
        menu.hidden = false;
        requestAnimationFrame(function () { menu.classList.add('is-open'); });
        var first = menu.querySelector('a');
        if (first) setTimeout(function () { first.focus({ preventScroll: true }); }, 60);
      } else {
        menu.classList.remove('is-open');
        setTimeout(function () { if (!open) menu.hidden = true; }, reduceMotion() ? 0 : 300);
        if (returnFocus) toggle.focus();
      }
    }

    toggle.addEventListener('click', function () { setOpen(!open, false); });
    menu.addEventListener('click', function (e) {
      if (e.target.closest('a')) setOpen(false, false);
    });
    doc.addEventListener('keydown', function (e) {
      if (open && e.key === 'Escape') setOpen(false, true);
    });
    window.addEventListener('resize', function () {
      if (open && window.innerWidth > 920) setOpen(false, false);
    });
  })();

  /* ---------- Reveal system ---------- */
  (function reveals() {
    var singles = Array.prototype.slice.call(doc.querySelectorAll('[data-reveal]'));
    var groups = Array.prototype.slice.call(doc.querySelectorAll('[data-stagger]'));

    // Assign stagger delays to children
    groups.forEach(function (group) {
      var base = parseInt(getComputedStyle(group).getPropertyValue('--stagger-base'), 10) || 0;
      var step = parseInt(group.getAttribute('data-stagger'), 10) || 110;
      Array.prototype.slice.call(group.querySelectorAll('[data-reveal-item]')).forEach(function (item, i) {
        item.style.setProperty('--sd', (base + i * step) + 'ms');
      });
    });

    var targets = singles.concat(groups);
    if (!('IntersectionObserver' in window) || reduceMotion()) {
      targets.forEach(function (el) { el.classList.add('is-visible'); });
      return;
    }
    var io = new IntersectionObserver(function (entries) {
      entries.forEach(function (entry) {
        if (entry.isIntersecting) {
          entry.target.classList.add('is-visible');
          io.unobserve(entry.target); // reveal once
        }
      });
    }, { rootMargin: '0px 0px -12% 0px', threshold: 0.12 });
    targets.forEach(function (el) { io.observe(el); });
  })();

  /* ---------- Portfolio carousel ---------- */
  (function carousel() {
    var region = doc.getElementById('carousel');
    var track = doc.getElementById('carouselTrack');
    var prev = doc.getElementById('carouselPrev');
    var next = doc.getElementById('carouselNext');
    var current = doc.getElementById('carouselCurrent');
    var total = doc.getElementById('carouselTotal');
    var bar = doc.getElementById('carouselBar');
    if (!region || !track) return;

    var slides = Array.prototype.slice.call(track.children);
    var count = slides.length;
    var index = 0;        // current stop
    var offsets = [];     // left edge of each slide, relative to the first
    var stops = [];       // track positions we can rest at; the last one shows the final company flush right
    var viewW = 0, trackW = 0;

    var status = doc.createElement('p');
    status.className = 'visually-hidden';
    status.setAttribute('aria-live', 'polite');
    region.appendChild(status);

    function pad(n) { return n < 10 ? '0' + n : String(n); }

    function measure() {
      var base = slides[0].offsetLeft;
      offsets = slides.map(function (s) { return s.offsetLeft - base; });
      var last = slides[count - 1];
      trackW = offsets[count - 1] + last.offsetWidth;
      var vp = track.parentElement;
      var cs = getComputedStyle(vp);
      viewW = vp.clientWidth - parseFloat(cs.paddingLeft) - parseFloat(cs.paddingRight);
      // Never scroll past the point where the last company is fully in view
      var maxShift = Math.max(0, Math.round(trackW - viewW));
      stops = [0];
      offsets.forEach(function (o) { if (o > 1 && o < maxShift - 1) stops.push(o); });
      if (maxShift > 1) stops.push(maxShift);
      if (index > stops.length - 1) index = stops.length - 1;
    }

    function setTransform(x) {
      track.style.transform = 'translate3d(' + (-x) + 'px,0,0)';
    }

    function visibleRange(x) {
      var first = -1, lastVisible = -1;
      slides.forEach(function (s, i) {
        var left = offsets[i] - x;
        var inside = left >= -2 && left + s.offsetWidth <= viewW + 2;
        s.classList.toggle('is-outside', !inside);
        if (inside) { if (first < 0) first = i; lastVisible = i; }
      });
      return [first, lastVisible];
    }

    function update(announce) {
      var x = stops[index] || 0;
      setTransform(x);
      var range = visibleRange(x);
      var n = stops.length;
      prev.disabled = index === 0;
      next.disabled = index === n - 1;
      current.textContent = pad(index + 1);
      total.textContent = pad(n);
      // Progress bar behaves like a scrollbar: thumb = visible share, position = scroll position
      if (bar) {
        var share = trackW > 0 ? Math.min(1, viewW / trackW) : 1;
        bar.style.width = (share * 100) + '%';
        bar.style.transform = 'translateX(' + (viewW > 0 ? (x / viewW) * 100 : 0) + '%)';
      }
      if (announce && range[0] >= 0) {
        status.textContent = range[0] === range[1]
          ? 'Showing company ' + (range[0] + 1) + ' of ' + count
          : 'Showing companies ' + (range[0] + 1) + ' to ' + (range[1] + 1) + ' of ' + count;
      }
    }

    function go(i, announce) {
      index = Math.max(0, Math.min(stops.length - 1, i));
      update(announce !== false);
    }

    prev.addEventListener('click', function () { go(index - 1); });
    next.addEventListener('click', function () { go(index + 1); });

    region.addEventListener('keydown', function (e) {
      if (e.target !== region) return; // let links inside handle their own keys
      if (e.key === 'ArrowRight') { e.preventDefault(); go(index + 1); }
      else if (e.key === 'ArrowLeft') { e.preventDefault(); go(index - 1); }
      else if (e.key === 'Home') { e.preventDefault(); go(0); }
      else if (e.key === 'End') { e.preventDefault(); go(stops.length - 1); }
    });

    // Tabbing to a company that is out of view brings it into view
    track.addEventListener('focusin', function (e) {
      var slide = e.target.closest('.slide');
      if (!slide || !slide.classList.contains('is-outside')) return;
      var i = slides.indexOf(slide);
      for (var k = 0; k < stops.length; k++) {
        var left = offsets[i] - stops[k];
        if (left >= -2 && left + slide.offsetWidth <= viewW + 2) { go(k); return; }
      }
    });

    // Pointer / touch drag (horizontal only; vertical swipes still scroll the page)
    var startX = 0, startY = 0, dx = 0, dragging = false, locked = null, pid = null, suppressClick = false;
    track.addEventListener('pointerdown', function (e) {
      if (e.pointerType === 'mouse' && e.button !== 0) return;
      dragging = true; locked = null; dx = 0; pid = e.pointerId; suppressClick = false;
      startX = e.clientX; startY = e.clientY;
    });
    track.addEventListener('pointermove', function (e) {
      if (!dragging || e.pointerId !== pid) return;
      var mx = e.clientX - startX, my = e.clientY - startY;
      if (locked === null && (Math.abs(mx) > 6 || Math.abs(my) > 6)) {
        locked = Math.abs(mx) > Math.abs(my) ? 'x' : 'y';
        if (locked === 'x') { suppressClick = true; track.classList.add('is-dragging'); try { track.setPointerCapture(pid); } catch (err) {} }
      }
      if (locked !== 'x') return;
      dx = mx;
      var atEdge = (index === 0 && dx > 0) || (index === stops.length - 1 && dx < 0);
      setTransform((stops[index] || 0) - (atEdge ? dx * 0.3 : dx));
    });
    // Only pointerup / pointercancel end a drag. Touch input fires lostpointercapture when the
    // browser's implicit capture hands over to ours, which used to cut swipes short.
    function endDrag(e) {
      if (!dragging || (e && e.pointerId !== pid)) return;
      dragging = false;
      track.classList.remove('is-dragging');
      if (locked === 'x') {
        var threshold = Math.min(80, (slides[0].offsetWidth || 300) * 0.18);
        if (dx < -threshold) go(index + 1);
        else if (dx > threshold) go(index - 1);
        else update(false);
      }
      locked = null;
    }
    track.addEventListener('pointerup', endDrag);
    track.addEventListener('pointercancel', endDrag);
    // A drag must not also open the company's website
    track.addEventListener('click', function (e) {
      if (suppressClick) { e.preventDefault(); e.stopPropagation(); suppressClick = false; }
    }, true);

    var resizeTimer;
    window.addEventListener('resize', function () {
      clearTimeout(resizeTimer);
      resizeTimer = setTimeout(function () { measure(); update(false); }, 120);
    });

    measure();
    update(false);
    if (doc.fonts && doc.fonts.ready) doc.fonts.ready.then(function () { measure(); update(false); });
    window.addEventListener('load', function () { measure(); update(false); });
  })();

  /* ---------- Pitch to Groove drawer ---------- */
  (function pitchDrawer() {
    var dialog = doc.getElementById('pitch');
    var form = doc.getElementById('pitchForm');
    if (!dialog || !form || typeof dialog.showModal !== 'function') return; // falls back to #pitch anchor
    var TO = 'hello@groove.com.au';
    var formStep = dialog.querySelector('[data-pitch-step="form"]');
    var doneStep = dialog.querySelector('[data-pitch-step="done"]');
    var copiedMsg = dialog.querySelector('.pitch__copied');
    var opener = null;
    var lastPitch = '';

    function open(trigger) {
      if (dialog.open) return;
      opener = trigger || doc.activeElement;
      showStep('form');
      dialog.showModal();
      body.classList.add('drawer-open');
      requestAnimationFrame(function () { dialog.classList.add('is-open'); });
      var first = form.querySelector('input');
      if (first) setTimeout(function () { first.focus({ preventScroll: true }); }, reduceMotion() ? 0 : 120);
    }

    function close() {
      if (!dialog.open) return;
      dialog.classList.remove('is-open');
      body.classList.remove('drawer-open');
      setTimeout(function () {
        dialog.close();
        if (opener && opener.focus) opener.focus({ preventScroll: true });
      }, reduceMotion() ? 0 : 420);
      if (location.hash === '#pitch') history.replaceState(null, '', location.pathname + location.search);
    }

    function showStep(step) {
      formStep.hidden = step !== 'form';
      doneStep.hidden = step !== 'done';
      copiedMsg.textContent = '';
    }

    // Every "Pitch to Groove" button opens the drawer
    doc.addEventListener('click', function (e) {
      var trigger = e.target.closest('[data-pitch-open]');
      if (!trigger) return;
      e.preventDefault();
      // If the mobile menu is open, close it first
      var toggle = doc.getElementById('menuToggle');
      if (body.classList.contains('menu-open') && toggle) toggle.click();
      open(trigger.closest('#mobileMenu') ? toggle : trigger);
    });
    dialog.querySelectorAll('[data-pitch-close]').forEach(function (b) { b.addEventListener('click', close); });
    // Esc: animate out instead of the instant native close
    dialog.addEventListener('cancel', function (e) { e.preventDefault(); close(); });
    // Click on the dimmed backdrop closes
    dialog.addEventListener('mousedown', function (e) { if (e.target === dialog) close(); });

    // Deep link: groove.com.au/#pitch opens the drawer
    if (location.hash === '#pitch') open(null);
    window.addEventListener('hashchange', function () { if (location.hash === '#pitch') open(null); });

    /* --- Validation (custom messages, announced and linked to each field) --- */
    var messages = {
      name: 'Please add your name.',
      email: 'Please add an email address we can reply to.',
      company: 'Please add your company name.',
      stage: 'Please choose your stage.',
      location: 'Please choose where you are based.',
      deck: 'Please add a link to your deck, starting with https://',
      note: 'Please add a short note about the business.'
    };
    function errorEl(field) { return doc.getElementById(field.id + '-error'); }
    function validate(field) {
      var el = errorEl(field);
      if (!el) return true;
      var msg = '';
      if (field.validity.valueMissing) msg = messages[field.name];
      else if (field.validity.typeMismatch) msg = field.name === 'email' ? 'Please check the email address.' : messages[field.name];
      el.textContent = msg;
      if (msg) {
        field.setAttribute('aria-invalid', 'true');
        var described = (field.getAttribute('aria-describedby') || '').split(' ').filter(Boolean);
        if (described.indexOf(el.id) < 0) { described.push(el.id); field.setAttribute('aria-describedby', described.join(' ')); }
      } else {
        field.removeAttribute('aria-invalid');
      }
      return !msg;
    }
    form.querySelectorAll('input, select, textarea').forEach(function (f) {
      f.addEventListener('blur', function () { if (f.value) validate(f); });
      f.addEventListener('input', function () { if (f.getAttribute('aria-invalid')) validate(f); });
      f.addEventListener('change', function () { if (f.getAttribute('aria-invalid')) validate(f); });
    });

    function compose() {
      var d = {};
      ['name', 'email', 'company', 'website', 'stage', 'location', 'deck', 'note'].forEach(function (k) {
        d[k] = (form.elements[k].value || '').trim();
      });
      var lines = [
        'Hi Groove,',
        '',
        d.note,
        '',
        'Company: ' + d.company,
        d.website ? 'Website: ' + d.website : null,
        'Stage: ' + d.stage,
        'Based in: ' + d.location,
        'Deck: ' + d.deck,
        '',
        d.name,
        d.email
      ].filter(function (l) { return l !== null; });
      return { subject: 'Pitch: ' + d.company, body: lines.join('\n') };
    }

    form.addEventListener('submit', function (e) {
      e.preventDefault();
      var fields = Array.prototype.slice.call(form.querySelectorAll('[required]'));
      var invalid = fields.filter(function (f) { return !validate(f); });
      if (invalid.length) { invalid[0].focus(); return; }
      var mail = compose();
      lastPitch = 'To: ' + TO + '\nSubject: ' + mail.subject + '\n\n' + mail.body;
      window.location.href = 'mailto:' + TO + '?subject=' + encodeURIComponent(mail.subject) + '&body=' + encodeURIComponent(mail.body);
      showStep('done');
      var title = doneStep.querySelector('.pitch__title');
      if (title) title.focus();
    });

    dialog.querySelector('[data-pitch-back]').addEventListener('click', function () {
      showStep('form');
      var first = form.querySelector('input'); if (first) first.focus();
    });
    dialog.querySelector('[data-pitch-copy]').addEventListener('click', function () {
      function done(ok) { copiedMsg.textContent = ok ? 'Copied. Paste it into an email to hello@groove.com.au.' : 'Copy didn’t work here. Please select and copy your note manually.'; }
      if (navigator.clipboard && navigator.clipboard.writeText) {
        navigator.clipboard.writeText(lastPitch).then(function () { done(true); }, function () { done(false); });
      } else {
        var ta = doc.createElement('textarea'); ta.value = lastPitch; ta.setAttribute('readonly', '');
        ta.style.position = 'fixed'; ta.style.opacity = '0'; dialog.appendChild(ta); ta.select();
        var ok = false; try { ok = doc.execCommand('copy'); } catch (err) {}
        dialog.removeChild(ta); done(ok);
      }
    });
  })();

  /* ---------- Book parallax (subtle) ---------- */
  (function bookParallax() {
    var book = doc.getElementById('bookParallax');
    if (!book || reduceMotion()) return;
    var visible = false, raf = null;
    var MAX_Y = 12;   // px
    var MAX_R = 2.5;  // deg

    function frame() {
      raf = null;
      var r = book.getBoundingClientRect();
      var vh = window.innerHeight;
      // -1 (below viewport centre) .. 1 (above)
      var p = ((r.top + r.height / 2) - vh / 2) / (vh / 2 + r.height / 2);
      p = Math.max(-1, Math.min(1, p));
      book.style.setProperty('--py', (p * MAX_Y).toFixed(2) + 'px');
      book.style.setProperty('--ry', (p * MAX_R).toFixed(2) + 'deg');
    }
    function onScroll() { if (visible && !raf) raf = requestAnimationFrame(frame); }

    if ('IntersectionObserver' in window) {
      new IntersectionObserver(function (entries) {
        visible = entries[0].isIntersecting;
        if (visible) onScroll();
      }).observe(book);
    } else { visible = true; }
    window.addEventListener('scroll', onScroll, { passive: true });
    frame();

    /* Hover tilt + sheen (mouse / trackpad only) */
    var stage = book.closest('.book__visual');
    var sheen = book.querySelector('.book-3d__sheen');
    var finePointer = window.matchMedia('(hover: hover) and (pointer: fine)').matches;
    if (!stage || !finePointer) return;
    var hoverRaf = null, px = 0, pyy = 0;
    function applyTilt() {
      hoverRaf = null;
      book.style.setProperty('--hry', (px * 18).toFixed(2) + 'deg');   // left/right
      book.style.setProperty('--hrx', (-pyy * 10).toFixed(2) + 'deg'); // up/down
      if (sheen) sheen.style.setProperty('--sheen', (px * 160).toFixed(1) + '%');
    }
    stage.addEventListener('pointerenter', function () { stage.classList.add('is-hovering'); });
    stage.addEventListener('pointermove', function (e) {
      var r = stage.getBoundingClientRect();
      px = (e.clientX - r.left) / r.width - 0.5;
      pyy = (e.clientY - r.top) / r.height - 0.5;
      if (!hoverRaf) hoverRaf = requestAnimationFrame(applyTilt);
    });
    stage.addEventListener('pointerleave', function () {
      stage.classList.remove('is-hovering');
      book.style.setProperty('--hry', '0deg');
      book.style.setProperty('--hrx', '0deg');
      if (sheen) sheen.style.setProperty('--sheen', '-110%');
    });
  })();
})();
