using './main.bicep'

// Values come from environment variables exported by scripts/provision.sh,
// so nothing environment-specific is hard-coded in the repo.
param stage = readEnvironmentVariable('STAGE', 'prod')
param githubSubjectPrefix = readEnvironmentVariable('GITHUB_SUBJECT_PREFIX', '')
param githubRepo = readEnvironmentVariable('GITHUB_REPO', 'groove-marketing-web')
param planSku = readEnvironmentVariable('PLAN_SKU', 'F1')
param linuxFxVersion = readEnvironmentVariable('LINUX_FX_VERSION', 'NODE|24-lts')
param alertEmail = readEnvironmentVariable('ALERT_EMAIL', '')
param prodCanonicalHost = readEnvironmentVariable('PROD_CANONICAL_HOST', '')
param location = 'australiaeast'
