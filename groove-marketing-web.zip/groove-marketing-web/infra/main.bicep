// =============================================================================
// groove.com.au marketing site - Azure infrastructure (PRODUCTION ONLY)
// Deploys into an EXISTING resource group (prod-groove-marketingweb-rg-aue).
// The dev branch is hosted on a Cloudflare Worker (*.workers.dev), not here.
//
//   prod-groove-marketingweb-asp-aue      App Service plan (Linux)
//   prod-groove-marketingweb-log-aue      Log Analytics workspace
//   prod-groove-marketingweb-appsvc-aue   Web app + App Insights (GitHub branch/env: prod, manual deploy)
//   prod-groove-marketingweb-id-aue       GitHub OIDC identity -> prod app only, trusts environment:prod
// =============================================================================
targetScope = 'resourceGroup'

@description('''What to deploy, so it can be built step by step:
  shared = Log Analytics + App Service plan
  prod   = shared + prod web app, App Insights, GitHub deploy identity, alerting''')
@allowed([
  'shared'
  'prod'
])
param stage string = 'prod'

@description('Azure region for all resources.')
param location string = 'australiaeast'

@description('Workload segment used in resource names.')
param workload string = 'groove-marketingweb'

@description('Region short code used in resource names.')
param regionCode string = 'aue'

@description('''App Service plan SKU.
F1 = Free: no custom domains, no SSL bindings, no Always On, 60 CPU-minutes/day per app, no SLA.
B1 or higher is required before groove.com.au can be bound.''')
@allowed([
  'F1'
  'B1'
  'B2'
  'B3'
  'S1'
  'P0v3'
  'P1v3'
])
param planSku string = 'F1'

@description('Linux runtime stack, e.g. NODE|24-lts, NODE|22-lts, DOTNETCORE|9.0, PYTHON|3.13.')
param linuxFxVersion string = 'NODE|24-lts'

@description('Startup command. The deploy bundle ships .github/deploy/server.js, which serves the static site.')
param startupCommand string = 'node server.js'

@description('Optional canonical host for prod, e.g. groove.com.au. Other custom hostnames (www) then 301 to it. Leave empty until go-live.')
param prodCanonicalHost string = ''

@description('''OIDC subject prefix of the GitHub repo (resolved by scripts/provision.sh).
Repos created after 2026-07-15 use the immutable form repo:OWNER@OWNER_ID/REPO@REPO_ID;
older repos use repo:OWNER/REPO unless opted in. Required for stage prod.''')
param githubSubjectPrefix string = ''

@description('GitHub repository name.')
param githubRepo string = 'groove-marketing-web'

@description('GitHub environment name. Must match the "environment:" used in deploy-prod.yml.')
param githubProdEnvironment string = 'prod'

@description('Email that receives prod Failure Anomalies alerts. Leave empty to skip the alert.')
param alertEmail string = ''

@description('Extra app settings for prod (merged over the defaults).')
param prodAppSettings object = {}

@description('Log Analytics retention in days.')
@minValue(30)
@maxValue(730)
param logRetentionDays int = 30

param tags object = {
  workload: 'groove-marketing-web'
  owner: 'JRC IT Operations'
  managedBy: 'bicep'
  repo: 'groove-marketing-web'
}

// -----------------------------------------------------------------------------
// Names
// -----------------------------------------------------------------------------
var planName = 'prod-${workload}-asp-${regionCode}'
var logName = 'prod-${workload}-log-${regionCode}'
var prodAppName = 'prod-${workload}-appsvc-${regionCode}'
var prodIdentityName = 'prod-${workload}-id-${regionCode}'

var skuTier = {
  F1: 'Free'
  B1: 'Basic'
  B2: 'Basic'
  B3: 'Basic'
  S1: 'Standard'
  P0v3: 'PremiumV3'
  P1v3: 'PremiumV3'
}
var isFreeTier = planSku == 'F1'
var deployProd = stage == 'prod'

// -----------------------------------------------------------------------------
// Shared: Log Analytics + App Service plan
// -----------------------------------------------------------------------------
resource logs 'Microsoft.OperationalInsights/workspaces@2023-09-01' = {
  name: logName
  location: location
  tags: union(tags, { environment: 'shared' })
  properties: {
    sku: {
      name: 'PerGB2018'
    }
    retentionInDays: logRetentionDays
    features: {
      enableLogAccessUsingOnlyResourcePermissions: true
    }
  }
}

resource plan 'Microsoft.Web/serverfarms@2024-04-01' = {
  name: planName
  location: location
  tags: union(tags, { environment: 'shared' })
  kind: 'linux'
  sku: {
    name: planSku
    tier: skuTier[planSku]
  }
  properties: {
    reserved: true // required for Linux
  }
}

// -----------------------------------------------------------------------------
// GitHub OIDC identity for the prod environment
// -----------------------------------------------------------------------------
module prodIdentity 'modules/github-identity.bicep' = if (deployProd) {
  name: 'id-prod'
  params: {
    name: prodIdentityName
    location: location
    tags: union(tags, { environment: 'production' })
    subjectPrefix: githubSubjectPrefix
    githubRepo: githubRepo
    githubEnvironment: githubProdEnvironment
  }
}

// -----------------------------------------------------------------------------
// Prod web app
// -----------------------------------------------------------------------------
module prodApp 'modules/webapp.bicep' = if (deployProd) {
  name: 'app-prod'
  params: {
    name: prodAppName
    location: location
    tags: union(tags, { environment: 'production' })
    planId: plan.id
    linuxFxVersion: linuxFxVersion
    alwaysOn: !isFreeTier
    startupCommand: startupCommand
    appEnv: 'production'
    logAnalyticsWorkspaceId: logs.id
    deployerPrincipalId: prodIdentity!.outputs.principalId
    extraAppSettings: union(empty(prodCanonicalHost) ? {} : { CANONICAL_HOST: prodCanonicalHost }, prodAppSettings)
  }
}

// -----------------------------------------------------------------------------
// Prod alerting (mirrors the "Failure Anomalies" rule on the JRC site)
// -----------------------------------------------------------------------------
resource actionGroup 'Microsoft.Insights/actionGroups@2023-01-01' = if (deployProd && !empty(alertEmail)) {
  name: 'prod-${workload}-ag-${regionCode}'
  location: 'Global'
  tags: union(tags, { environment: 'production' })
  properties: {
    groupShortName: 'groove-web'
    enabled: true
    emailReceivers: [
      {
        name: 'it-operations'
        emailAddress: alertEmail
        useCommonAlertSchema: true
      }
    ]
  }
}

resource failureAnomalies 'Microsoft.AlertsManagement/smartDetectorAlertRules@2021-04-01' = if (deployProd && !empty(alertEmail)) {
  name: 'Failure Anomalies - ${prodAppName}'
  location: 'global'
  tags: union(tags, { environment: 'production' })
  properties: {
    description: 'Detects an abnormal rise in failed requests on the Groove prod site.'
    state: 'Enabled'
    severity: 'Sev3'
    frequency: 'PT1M'
    detector: {
      id: 'FailureAnomaliesDetector'
    }
    scope: [
      prodApp!.outputs.appInsightsId
    ]
    actionGroups: {
      groupIds: [
        actionGroup!.id
      ]
    }
  }
}

// -----------------------------------------------------------------------------
// Outputs (consumed by scripts/configure-github.sh and bind-custom-domains.sh)
// -----------------------------------------------------------------------------
output stage string = stage
output tenantId string = tenant().tenantId
output subscriptionId string = subscription().subscriptionId
output resourceGroup string = resourceGroup().name
output planName string = plan.name
output planSku string = planSku
output logWorkspaceName string = logs.name

// Empty strings for parts not deployed in this stage.
output prodAppName string = deployProd ? prodApp!.outputs.name : ''
output prodDefaultHostname string = deployProd ? prodApp!.outputs.defaultHostname : ''
output prodClientId string = deployProd ? prodIdentity!.outputs.clientId : ''
output prodOidcSubject string = deployProd ? prodIdentity!.outputs.subject : ''

@description('Same value for every app in the subscription; goes in the asuid TXT records.')
output customDomainVerificationId string = deployProd ? prodApp!.outputs.customDomainVerificationId : ''
