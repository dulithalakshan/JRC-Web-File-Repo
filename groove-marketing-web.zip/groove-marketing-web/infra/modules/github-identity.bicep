// User-assigned managed identity that a single GitHub Actions environment can
// sign in as (OIDC / workload identity federation - no secrets stored anywhere).

param name string
param location string
param tags object

@description('''Subject prefix GitHub puts in the OIDC token for this repo.
Repos created after 2026-07-15 (or opted in): repo:OWNER@OWNER_ID/REPO@REPO_ID
Older repos:                                 repo:OWNER/REPO''')
param subjectPrefix string

@description('Repository name (used for the credential name only).')
param githubRepo string

@description('GitHub environment name. Only jobs that declare "environment: <this>" get a token.')
param githubEnvironment string

resource identity 'Microsoft.ManagedIdentity/userAssignedIdentities@2023-01-31' = {
  name: name
  location: location
  tags: tags
}

resource federation 'Microsoft.ManagedIdentity/userAssignedIdentities/federatedIdentityCredentials@2023-01-31' = {
  parent: identity
  name: 'github-${githubRepo}-${githubEnvironment}'
  properties: {
    issuer: 'https://token.actions.githubusercontent.com'
    subject: '${subjectPrefix}:environment:${githubEnvironment}'
    audiences: [
      'api://AzureADTokenExchange'
    ]
  }
}

output principalId string = identity.properties.principalId
output clientId string = identity.properties.clientId
output subject string = federation.properties.subject
