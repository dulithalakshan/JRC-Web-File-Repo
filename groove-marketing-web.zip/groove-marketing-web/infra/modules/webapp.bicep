// One Linux web app + its workspace-based Application Insights, locked down
// for OIDC-only deployments (FTP and SCM basic auth disabled).

param name string
param location string
param tags object
param planId string
param linuxFxVersion string
param startupCommand string
param alwaysOn bool

@description('APP_ENV seen by the site host. Anything other than "production" is kept out of search engines.')
param appEnv string = 'production'

param logAnalyticsWorkspaceId string

@description('Principal that GitHub Actions signs in as; gets Website Contributor on this app only.')
param deployerPrincipalId string

param extraAppSettings object = {}

// Website Contributor - built-in role
var websiteContributorRoleId = 'de139f84-1756-47ae-9be6-808fbbe84772'

resource appInsights 'Microsoft.Insights/components@2020-02-02' = {
  name: name
  location: location
  tags: tags
  kind: 'web'
  properties: {
    Application_Type: 'web'
    WorkspaceResourceId: logAnalyticsWorkspaceId
    IngestionMode: 'LogAnalytics'
  }
}

var baseAppSettings = {
  APP_ENV: appEnv
  NODE_ENV: 'production'
  APPLICATIONINSIGHTS_CONNECTION_STRING: appInsights.properties.ConnectionString
  ApplicationInsightsAgent_EXTENSION_VERSION: '~3'
  // The workflow ships a pre-built package; don't rebuild on the server.
  SCM_DO_BUILD_DURING_DEPLOYMENT: 'false'
}

resource site 'Microsoft.Web/sites@2024-04-01' = {
  name: name
  location: location
  tags: union(tags, {
    'hidden-link: /app-insights-resource-id': appInsights.id
  })
  kind: 'app,linux'
  properties: {
    serverFarmId: planId
    httpsOnly: true
    clientAffinityEnabled: false
    publicNetworkAccess: 'Enabled'
    siteConfig: {
      linuxFxVersion: linuxFxVersion
      appCommandLine: startupCommand
      alwaysOn: alwaysOn
      ftpsState: 'Disabled'
      minTlsVersion: '1.2'
      scmMinTlsVersion: '1.2'
      http20Enabled: true
    }
  }
}

// NOTE: this replaces the full app-settings set on every provision run.
// Add permanent settings via prodAppSettings in main.bicep,
// not in the portal, or they will be removed on the next run.
resource appSettings 'Microsoft.Web/sites/config@2024-04-01' = {
  parent: site
  name: 'appsettings'
  properties: union(baseAppSettings, extraAppSettings)
}

// OIDC deployments don't need basic auth - turn it off for SCM (Kudu) and FTP.
resource scmBasicAuth 'Microsoft.Web/sites/basicPublishingCredentialsPolicies@2024-04-01' = {
  parent: site
  name: 'scm'
  properties: {
    allow: false
  }
}

resource ftpBasicAuth 'Microsoft.Web/sites/basicPublishingCredentialsPolicies@2024-04-01' = {
  parent: site
  name: 'ftp'
  properties: {
    allow: false
  }
}

resource deployerRole 'Microsoft.Authorization/roleAssignments@2022-04-01' = {
  name: guid(site.id, deployerPrincipalId, websiteContributorRoleId)
  scope: site
  properties: {
    roleDefinitionId: subscriptionResourceId('Microsoft.Authorization/roleDefinitions', websiteContributorRoleId)
    principalId: deployerPrincipalId
    principalType: 'ServicePrincipal'
    description: 'GitHub Actions (${appEnv}) deploys to ${name}'
  }
}

output name string = site.name
output id string = site.id
output defaultHostname string = site.properties.defaultHostName
output customDomainVerificationId string = site.properties.customDomainVerificationId
output appInsightsId string = appInsights.id
