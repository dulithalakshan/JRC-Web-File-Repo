#!/usr/bin/env bash
# -----------------------------------------------------------------------------
# Assemble the deploy bundle for App Service:
#   <out>/server.js  <out>/package.json  <out>/build-info.json  <out>/site/<website>
#
#   .github/deploy/package-site.sh <out-dir>
#
# SITE_DIR (env, default ".") = folder holding index.html, relative to the repo
# root. Leave as "." for the current plain static site; set it (repo variable
# SITE_DIR) if the developers later add a build step that outputs e.g. "dist".
# -----------------------------------------------------------------------------
set -euo pipefail

OUT="${1:?usage: package-site.sh <out-dir>}"
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/../.." && pwd)"
SITE_DIR="${SITE_DIR:-.}"
SRC="$(cd "$ROOT/$SITE_DIR" 2>/dev/null && pwd)" || { echo "::error::SITE_DIR '$SITE_DIR' not found"; exit 1; }

[[ -f "$SRC/index.html" ]] || { echo "::error::$SITE_DIR/index.html not found"; exit 1; }
mkdir -p "$OUT"
OUT="$(cd "$OUT" && pwd)"
case "$OUT/" in
  "$SRC/"*) echo "::error::Output folder must be outside the site folder ($SRC)"; exit 1 ;;
esac

rm -rf "${OUT:?}/"*
mkdir -p "$OUT/site"

# Website files only - repo tooling and docs are not published.
tar -C "$SRC" \
  --exclude=./.git --exclude=./.github --exclude=./infra --exclude=./scripts --exclude=./docs \
  --exclude=./node_modules --exclude=./README.md --exclude=./.gitignore --exclude=./.gitattributes \
  --exclude=./.editorconfig --exclude=./.vscode --exclude=./.idea --exclude=./.provision-outputs.json \
  --exclude=./package.json --exclude=./package-lock.json --exclude=./release.zip \
  -cf - . | tar -C "$OUT/site" -xf -

cp "$ROOT/.github/deploy/server.js" "$ROOT/.github/deploy/package.json" "$OUT/"

cat > "$OUT/build-info.json" <<EOF
{"commit": "${GITHUB_SHA:-local}", "ref": "${GITHUB_REF_NAME:-local}", "builtAt": "$(date -u +%Y-%m-%dT%H:%M:%SZ)"}
EOF

echo "Bundle ready: $OUT ($(find "$OUT/site" -type f | wc -l | tr -d ' ') site files, $(du -sh "$OUT" | cut -f1))"
