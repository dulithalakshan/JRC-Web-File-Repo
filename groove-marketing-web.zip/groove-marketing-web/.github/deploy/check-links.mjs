// Fails if any local file referenced by the site's HTML or CSS is missing
// (broken image, font, stylesheet or script path). External links aren't checked.
//
//   node .github/deploy/check-links.mjs <site-folder>

import { readFileSync, readdirSync, statSync } from 'node:fs';
import path from 'node:path';

const root = path.resolve(process.argv[2] ?? '.');
const SKIP = /^(?:[a-z][a-z0-9+.-]*:|\/\/|#|\{\{|\$\{)/i; // http:, mailto:, data:, //cdn, #anchor, templates

function walk(dir, out = []) {
  for (const name of readdirSync(dir)) {
    const full = path.join(dir, name);
    if (statSync(full).isDirectory()) walk(full, out);
    else out.push(full);
  }
  return out;
}

function refsIn(file) {
  const src = readFileSync(file, 'utf8');
  const refs = [];
  const push = (r) => r && refs.push(r.trim());
  if (file.endsWith('.html')) {
    for (const m of src.matchAll(/\s(?:src|href|poster|data-src)\s*=\s*["']([^"']*)["']/gi)) push(m[1]);
    for (const m of src.matchAll(/\ssrcset\s*=\s*["']([^"']*)["']/gi)) {
      for (const part of m[1].split(',')) push(part.trim().split(/\s+/)[0]);
    }
  }
  for (const m of src.matchAll(/url\(\s*(['"]?)([^'")]+)\1\s*\)/gi)) push(m[2]);
  for (const m of src.matchAll(/@import\s+(['"])([^'"]+)\1/gi)) push(m[2]);
  return refs;
}

function exists(target) {
  try {
    const st = statSync(target);
    return st.isFile() || (st.isDirectory() && statSync(path.join(target, 'index.html')).isFile());
  } catch {
    return false;
  }
}

const files = walk(root).filter((f) => /\.(html|css)$/i.test(f));
const missing = [];
let checked = 0;

for (const file of files) {
  for (const ref of refsIn(file)) {
    if (!ref || SKIP.test(ref)) continue;
    let clean = ref.split('#')[0].split('?')[0];
    if (!clean) continue;
    try {
      clean = decodeURI(clean);
    } catch {
      // keep as-is
    }
    const base = clean.startsWith('/') ? root : path.dirname(file);
    let target = path.join(base, clean);
    if (clean.endsWith('/')) target = path.join(target, 'index.html');
    checked++;
    if (!exists(target) && !exists(target + '.html')) {
      missing.push(`${path.relative(root, file)}: ${ref}`);
    }
  }
}

if (missing.length) {
  console.error(`Broken local references (${missing.length}):`);
  for (const m of missing) console.error(`  ${m}`);
  console.log(`::error::${missing.length} broken local reference(s) - see log`);
  process.exit(1);
}
console.log(`Link check OK: ${checked} local references in ${files.length} HTML/CSS files.`);
