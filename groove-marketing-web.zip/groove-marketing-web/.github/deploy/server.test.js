'use strict';
// Tests for the App Service host (run in CI: node --test .github/deploy/server.test.js)
const { test, before, after } = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const os = require('node:os');
const path = require('node:path');
const zlib = require('node:zlib');
const http = require('node:http');
const { createServer } = require('./server');

// Raw HTTP so we control Host / Accept-Encoding and see bytes as sent.
function get(url, { method = 'GET', headers = {} } = {}) {
  return new Promise((resolve, reject) => {
    const req = http.request(url, { method, headers }, (res) => {
      const chunks = [];
      res.on('data', (c) => chunks.push(c));
      res.on('end', () => resolve({ status: res.statusCode, headers: res.headers, body: Buffer.concat(chunks) }));
    });
    req.on('error', reject);
    req.end();
  });
}

let root;
const servers = [];

function start(opts) {
  return new Promise((resolve) => {
    const s = createServer({ root, buildInfo: { commit: 'abc123' }, ...opts });
    servers.push(s);
    s.listen(0, () => resolve(`http://127.0.0.1:${s.address().port}`));
  });
}

before(() => {
  root = fs.mkdtempSync(path.join(os.tmpdir(), 'groove-site-'));
  fs.mkdirSync(path.join(root, 'css'));
  fs.mkdirSync(path.join(root, 'about'));
  fs.writeFileSync(path.join(root, 'index.html'), '<!doctype html><title>Groove</title>' + 'x'.repeat(2000));
  fs.writeFileSync(path.join(root, 'css', 'styles.css'), 'body{color:#111}' + ' '.repeat(2000));
  fs.writeFileSync(path.join(root, 'about', 'index.html'), '<p>about</p>');
  fs.writeFileSync(path.join(root, '.env'), 'SECRET=1');
});

after(async () => {
  await Promise.all(servers.map((s) => new Promise((r) => s.close(r))));
  fs.rmSync(root, { recursive: true, force: true });
});

test('home page is served with revalidation caching', async () => {
  const base = await start({ appEnv: 'production' });
  const res = await get(`${base}/`);
  assert.equal(res.status, 200);
  assert.match(res.headers['content-type'], /text\/html/);
  assert.equal(res.headers['cache-control'], 'no-cache');
  assert.equal(res.headers['x-robots-tag'], undefined);
});

test('dev is kept out of search engines', async () => {
  const base = await start({ appEnv: 'dev' });
  assert.match((await get(`${base}/`)).headers['x-robots-tag'], /noindex/);
  assert.match((await get(`${base}/robots.txt`)).body.toString(), /Disallow: \//);
});

test('production allows indexing by default', async () => {
  const base = await start({ appEnv: 'production' });
  assert.match((await get(`${base}/robots.txt`)).body.toString(), /Allow: \//);
});

test('text assets are gzipped and support 304', async () => {
  const base = await start({ appEnv: 'production' });
  const res = await get(`${base}/css/styles.css`, { headers: { 'accept-encoding': 'gzip' } });
  assert.equal(res.status, 200);
  assert.equal(res.headers['content-encoding'], 'gzip');
  assert.match(zlib.gunzipSync(res.body).toString(), /^body\{color:#111\}/);
  const again = await get(`${base}/css/styles.css`, { headers: { 'if-none-match': res.headers.etag } });
  assert.equal(again.status, 304);
});

test('folder URLs resolve to index.html', async () => {
  const base = await start({ appEnv: 'production' });
  assert.equal((await get(`${base}/about`)).status, 200);
  assert.equal((await get(`${base}/about/`)).status, 200);
});

test('unsafe or unknown paths never return 200', async () => {
  const base = await start({ appEnv: 'production' });
  for (const p of ['/.env', '/%2e%2e/etc/passwd', '/..%2f..%2fetc/passwd', '/%00', '/%E0%A4%A', '/nope.html']) {
    assert.notEqual((await get(`${base}${p}`)).status, 200, p);
  }
  assert.equal((await get(`${base}/`, { method: 'POST' })).status, 405);
  assert.equal((await get(`${base}/`, { method: 'HEAD' })).status, 200);
});

test('canonical host redirect for custom domains only', async () => {
  const base = await start({ appEnv: 'production', canonicalHost: 'groove.com.au' });
  const www = await get(`${base}/about?x=1`, { headers: { host: 'www.groove.com.au' } });
  assert.equal(www.status, 301);
  assert.equal(www.headers.location, 'https://groove.com.au/about?x=1');
  const azure = await get(`${base}/`, { headers: { host: 'prod-groove-marketingweb-appsvc-aue.azurewebsites.net' } });
  assert.equal(azure.status, 200);
  assert.equal((await get(`${base}/`, { headers: { host: 'groove.com.au' } })).status, 200);
  assert.equal((await get(`${base}/healthz`, { headers: { host: 'www.groove.com.au' } })).status, 200);
});

test('healthz reports the deployed commit', async () => {
  const base = await start({ appEnv: 'dev' });
  const body = JSON.parse((await get(`${base}/healthz`)).body.toString());
  assert.equal(body.status, 'ok');
  assert.equal(body.commit, 'abc123');
});
