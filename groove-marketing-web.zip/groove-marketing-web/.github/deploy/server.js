'use strict';
// Tiny zero-dependency host for the static Groove site on Azure App Service (Linux, Node).
// The deploy bundle is:   server.js  package.json  build-info.json  site/<the website>
// Developers don't touch this; they just edit the static files in the repo.
//
// Env (App Service app settings):
//   PORT            set by App Service
//   APP_ENV         "production" or anything else (dev) - dev is kept out of search engines
//   CANONICAL_HOST  optional, e.g. "groove.com.au": other custom hostnames (www) 301 to it

const http = require('node:http');
const fs = require('node:fs');
const path = require('node:path');
const zlib = require('node:zlib');

const TYPES = {
  '.html': 'text/html; charset=utf-8',
  '.css': 'text/css; charset=utf-8',
  '.js': 'text/javascript; charset=utf-8',
  '.mjs': 'text/javascript; charset=utf-8',
  '.json': 'application/json; charset=utf-8',
  '.txt': 'text/plain; charset=utf-8',
  '.xml': 'application/xml; charset=utf-8',
  '.webmanifest': 'application/manifest+json',
  '.svg': 'image/svg+xml',
  '.png': 'image/png',
  '.jpg': 'image/jpeg',
  '.jpeg': 'image/jpeg',
  '.gif': 'image/gif',
  '.webp': 'image/webp',
  '.avif': 'image/avif',
  '.ico': 'image/x-icon',
  '.woff2': 'font/woff2',
  '.woff': 'font/woff',
  '.pdf': 'application/pdf',
  '.mp4': 'video/mp4',
};
const COMPRESSIBLE = new Set(['.html', '.css', '.js', '.mjs', '.json', '.txt', '.xml', '.svg', '.webmanifest']);

function cacheControl(ext) {
  if (ext === '.html') return 'no-cache'; // always revalidate pages
  if (ext === '.css' || ext === '.js' || ext === '.mjs') return 'public, max-age=3600';
  return 'public, max-age=604800'; // fonts, images: 7 days (file names aren't fingerprinted)
}

function createServer(opts = {}) {
  const root = path.resolve(opts.root || path.join(__dirname, 'site'));
  const appEnv = opts.appEnv ?? process.env.APP_ENV ?? 'local';
  const canonicalHost = (opts.canonicalHost ?? process.env.CANONICAL_HOST ?? '').toLowerCase();
  const buildInfo = opts.buildInfo ?? readJson(path.join(__dirname, 'build-info.json'));
  const isProd = appEnv === 'production';
  const gzCache = new Map();

  return http.createServer((req, res) => {
    const base = {
      'X-Content-Type-Options': 'nosniff',
      'Referrer-Policy': 'strict-origin-when-cross-origin',
      'X-Frame-Options': 'SAMEORIGIN',
    };
    if (!isProd) base['X-Robots-Tag'] = 'noindex, nofollow';
    if (req.headers['x-forwarded-proto'] === 'https' || req.headers['x-arr-ssl']) {
      base['Strict-Transport-Security'] = 'max-age=31536000';
    }

    const send = (status, headers, body) => {
      res.writeHead(status, { ...base, ...headers });
      res.end(req.method === 'HEAD' ? undefined : body);
    };
    const text = (status, body) => send(status, { 'Content-Type': TYPES['.txt'], 'Cache-Control': 'no-store' }, body);

    if (req.method !== 'GET' && req.method !== 'HEAD') {
      return send(405, { Allow: 'GET, HEAD', 'Content-Type': TYPES['.txt'] }, 'Method Not Allowed');
    }

    let pathname;
    try {
      pathname = decodeURIComponent(new URL(req.url, 'http://localhost').pathname);
    } catch {
      return text(400, 'Bad Request');
    }
    if (pathname.includes('\0')) return text(400, 'Bad Request');

    if (pathname === '/healthz') {
      return send(200, { 'Content-Type': TYPES['.json'], 'Cache-Control': 'no-store' },
        JSON.stringify({ status: 'ok', env: appEnv, ...buildInfo }));
    }

    // www.groove.com.au -> groove.com.au (only for custom domains, never *.azurewebsites.net)
    const host = String(req.headers.host || '').toLowerCase().replace(/:\d+$/, '');
    if (canonicalHost && host && host !== canonicalHost
        && !host.endsWith('.azurewebsites.net') && host !== 'localhost' && host !== '127.0.0.1') {
      const target = new URL(req.url, `https://${canonicalHost}`);
      return send(301, { Location: target.href, 'Cache-Control': 'public, max-age=3600' }, '');
    }

    if (pathname === '/robots.txt' && !isProd) {
      return send(200, { 'Content-Type': TYPES['.txt'], 'Cache-Control': 'no-cache' }, 'User-agent: *\nDisallow: /\n');
    }

    // Never serve dotfiles (.env, .git ...) except /.well-known/
    if (pathname.split('/').some((seg) => seg.startsWith('.') && seg !== '.well-known')) {
      return notFound();
    }

    const file = resolveFile(root, pathname);
    if (!file) {
      if (pathname === '/robots.txt') {
        return send(200, { 'Content-Type': TYPES['.txt'], 'Cache-Control': 'no-cache' }, 'User-agent: *\nAllow: /\n');
      }
      return notFound();
    }
    return serveFile(file.path, file.stat, 200);

    function notFound() {
      const page = resolveFile(root, '/404.html');
      if (page) return serveFile(page.path, page.stat, 404);
      return text(404, 'Not Found');
    }

    function serveFile(filePath, stat, status) {
      const ext = path.extname(filePath).toLowerCase();
      const etag = `W/"${stat.size.toString(16)}-${Math.floor(stat.mtimeMs).toString(16)}"`;
      const headers = {
        'Content-Type': TYPES[ext] || 'application/octet-stream',
        'Cache-Control': cacheControl(ext),
        ETag: etag,
        'Last-Modified': stat.mtime.toUTCString(),
      };
      if (status === 200 && req.headers['if-none-match'] === etag) {
        return send(304, { ETag: etag, 'Cache-Control': headers['Cache-Control'] });
      }
      let body;
      try {
        body = fs.readFileSync(filePath);
      } catch {
        return text(404, 'Not Found');
      }
      if (COMPRESSIBLE.has(ext)) {
        headers.Vary = 'Accept-Encoding';
        if (/\bgzip\b/.test(req.headers['accept-encoding'] || '')) {
          const key = `${filePath}:${etag}`;
          let gz = gzCache.get(key);
          if (!gz) {
            gz = zlib.gzipSync(body);
            gzCache.set(key, gz);
          }
          headers['Content-Encoding'] = 'gzip';
          body = gz;
        }
      }
      headers['Content-Length'] = body.length;
      return send(status, headers, body);
    }
  });
}

// Map a URL path to a file under root: /, /about, /about/, /about.html
function resolveFile(root, pathname) {
  const candidates = pathname.endsWith('/')
    ? [pathname + 'index.html']
    : [pathname, pathname + '.html', pathname + '/index.html'];
  for (const candidate of candidates) {
    const full = path.normalize(path.join(root, candidate));
    if (full !== root && !full.startsWith(root + path.sep)) return null;
    try {
      const stat = fs.statSync(full);
      if (stat.isFile()) return { path: full, stat };
    } catch {
      // try next candidate
    }
  }
  return null;
}

function readJson(file) {
  try {
    return JSON.parse(fs.readFileSync(file, 'utf8'));
  } catch {
    return {};
  }
}

if (require.main === module) {
  const port = Number(process.env.PORT) || 8080;
  createServer().listen(port, () => {
    console.log(`groove site listening on :${port} (APP_ENV=${process.env.APP_ENV || 'local'})`);
  });
}

module.exports = { createServer };
