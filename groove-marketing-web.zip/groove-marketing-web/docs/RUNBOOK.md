# groove-marketing-web: IT Operations runbook

Owner: JRC IT Operations · Repo: `JRC-Software/groove-marketing-web` · Azure: JRC - Microsoft Azure Sponsorship (`0dbd7b35-50c0-4303-8aed-1a417aaf7b9e`), Australia East · DNS: Cloudflare (registrar GoDaddy)

## 1. How it fits together

```
 developers ──push──▶ dev branch ──Deploy dev (AUTOMATIC)──▶ Cloudflare Worker (static assets)
                          │                                   groove-marketing-web-dev.<sub>.workers.dev
                          │ PR "Release: …"
                          ▼
 IT Operations ──merge──▶ prod branch        (merging does NOT deploy)
 IT Operations ──Run workflow──▶ Deploy prod (MANUAL) ──▶ Azure App Service prod-groove-marketingweb-appsvc-aue
                                   (OIDC as prod-groove-marketingweb-id-aue, can only touch the prod app)

 Cloudflare DNS: groove.com.au, www ──▶ prod app   (dev needs no DNS)
```

| Branch | GitHub environment | Hosted on | Deploys | Secrets in that environment |
|---|---|---|---|---|
| `dev` (default) | `dev` | Cloudflare Workers, `*.workers.dev` | automatically on every push | `CLOUDFLARE_API_TOKEN`, `CLOUDFLARE_ACCOUNT_ID` |
| `prod` | `prod` | Azure App Service (F1 → B1 at go-live) | **manually**: Actions → Deploy prod → Run workflow | `AZURE_CLIENT_ID`, `AZURE_TENANT_ID`, `AZURE_SUBSCRIPTION_ID` |

**The site** is plain static HTML/CSS/JS in the repo root, with no build step.

- **Dev** is published as Cloudflare static assets: no server code, free, and asset requests are unlimited. A generated `_headers` file adds noindex and security headers, `robots.txt` blocks all crawlers, and `/build-info.json` shows the live commit.
- **Prod** is bundled with `.github/deploy/server.js`, a zero-dependency Node host. It adds gzip, cache and security headers, an optional www→apex redirect, and `/healthz`. App Service runs it with `node server.js` on Node 24 LTS.

### What stops a developer deploying to prod

1. **Branch protection on `prod`**: only the IT team can merge, only via PR, and CI must pass.
2. **`prod` environment**: only the `prod` branch may use it, and only it holds the Azure secrets. Dev workflows never see them.
3. **`PROD_DEPLOYERS` repo variable**: the deploy job checks who clicked *Run workflow* (or *Re-run*) and stops anyone not on the list. Only repo admins can change it.
4. **Azure identity**: trusts only `environment:prod` of this repo, and only has rights on the prod app.
5. Optional: **required reviewers** on `prod` (Enterprise or public repo only).

No passwords or publish profiles exist in Azure: FTP/SCM basic auth is disabled.

**About the Cloudflare token:** whoever can push to `dev` can change the dev workflow, so treat `CLOUDFLARE_API_TOKEN` as visible to developers. Give it only **Workers Scripts: Edit** on one account, and don't use an account that also runs other important Workers. If it does, create a separate free Cloudflare account just for the Groove dev site.

### Azure resources in `prod-groove-marketingweb-rg-aue`

| Resource | Name | Notes |
|---|---|---|
| App Service plan (Linux) | `prod-groove-marketingweb-asp-aue` | F1 now; B1 at go-live |
| Log Analytics | `prod-groove-marketingweb-log-aue` | 30-day retention |
| Web app + Application Insights | `prod-groove-marketingweb-appsvc-aue` | Node 24, `node server.js`, HTTPS only, TLS 1.2 |
| Managed identity | `prod-groove-marketingweb-id-aue` | GitHub OIDC, Website Contributor on the prod app only |
| Action group + Failure Anomalies | `prod-groove-marketingweb-ag-aue` | only if `--alert-email` given |

### GitHub plan check

| Control | GitHub Free, private repo | Team / Pro, private repo | Enterprise, or public repo |
|---|---|---|---|
| Environments + environment secrets | no | yes | yes |
| Branch protection (only IT merges to `prod`) | no | yes | yes |
| Deployment branch rules per environment | no | yes | yes |
| Required reviewers on prod deploys | no | no | yes |

## 2. One-time setup

> **Where to run the scripts:** they're Bash scripts. Use **Azure Cloud Shell → Bash** (portal.azure.com → `>_`). It already has `az`, Bicep, `gh`, `git` and `jq`. They won't run in Windows Command Prompt or PowerShell.

### 2.0 Cloud Shell

Upload `groove-marketing-web.zip` (**Manage files → Upload**), then:

```bash
unzip -o groove-marketing-web.zip && cd groove-marketing-web
az account set --subscription 0dbd7b35-50c0-4303-8aed-1a417aaf7b9e
gh auth login -s repo,workflow,admin:org
```

### Dev path (Cloudflare)

**D1. Cloudflare account ready.** In the Cloudflare dashboard → **Workers & Pages**:
- Note the **Account ID**.
- Make sure the account has a **workers.dev subdomain**; the first visit to Workers asks you to pick one.

**D2. API token.** Go to My Profile → API Tokens → Create Token → **Edit Cloudflare Workers** template (or a custom token with *Account → Workers Scripts → Edit*):
- **Account Resources:** only this account.
- **Zone Resources:** none needed.
- Optionally set an expiry date.

**D3. GitHub `dev` environment** (sets the two Cloudflare secrets; you'll be prompted for the token):

```bash
./scripts/configure-github.sh --stage dev --owner JRC-Software --cf-account-id <account-id> \
  --dev-team <dev-slug> --it-team <it-slug>
```

**D4. Add the pipeline to the repo** (you commit it). Copy `.github/`, `infra/`, `scripts/`, `docs/`, `README.md` and `.gitignore` from the package into your clone. The site files stay untouched. Then:

```bash
git switch dev
git add .github infra scripts docs README.md .gitignore
git commit -m "Add hosting pipeline (dev: Cloudflare, prod: Azure)"
git push origin dev                      # -> "Deploy dev" runs automatically
```

**D5. Verify:**
- [ ] Actions → **Deploy dev** is green, and the run summary shows the `workers.dev` URL.
- [ ] The URL shows the Groove site, and `/robots.txt` returns `Disallow: /`.
- [ ] `/build-info.json` shows the commit you pushed.

### Prod path (Azure)

**P1. Resource group** (done): `prod-groove-marketingweb-rg-aue`, Australia East. Your Azure account needs **Owner** (or Contributor + User Access Administrator) on it, because the deployment creates a role assignment.

**P2. Shared resources** (plan + Log Analytics):

```bash
./scripts/provision.sh --stage shared --what-if     # preview: 2 resources to create
./scripts/provision.sh --stage shared
```

**P3. Prod app + deploy identity:**

```bash
./scripts/provision.sh --stage prod --github-owner JRC-Software --what-if
./scripts/provision.sh --stage prod --github-owner JRC-Software --alert-email <it-alerts@…>
```

**P4. GitHub `prod` environment + protection:**

```bash
./scripts/configure-github.sh --stage prod --owner JRC-Software --it-team <it-slug> \
  --prod-deployers <your-login>,<colleague-login>
```

**P5. First prod deploy.** Open a PR **`dev` → `prod`** and merge it (merge commit). Then go to Actions → **Deploy prod** → **Run workflow**, choose branch **`prod`**, and enter release `initial`. Check that `https://prod-groove-marketingweb-appsvc-aue.azurewebsites.net/healthz` shows the commit.

## 3. Releasing to prod

1. A developer opens a PR **`dev` → `prod`** titled `Release: …`. That PR is their sign-off.
2. Check the dev site and that CI is green. Read the diff, especially anything under `.github/`, `infra/`, `scripts/`.
3. Merge with **Create a merge commit**. Don't squash: squashing makes `dev` and `prod` drift. **Merging does not deploy.**
4. When ready: **Actions → Deploy prod → Run workflow**, branch **`prod`**, fill in *release*. You must be in `PROD_DEPLOYERS`.
5. The smoke test waits until `/healthz` reports the new commit. The run title records what was released and who ran it.

## 4. Rollback

- **Prod, fastest** (runs from the last 30 days): Actions → *Deploy prod* → last good run → **Re-run all jobs**.
- **Prod, always works**: **Revert** the bad release PR (creates a revert PR into `prod`), merge it, then **Run workflow**.
- **Dev**: revert on `dev` and push, or in Cloudflare → Workers → `groove-marketing-web-dev` → Deployments → roll back.

## 5. Hotfix

Branch from `prod` → PR into `prod` → merge → **Run workflow** → then PR `prod` → `dev` so dev gets the fix too.

## 6. Go-live on groove.com.au

Free (F1) **cannot** use custom domains or certificates, and Cloudflare's Free plan can't work around that (Host-header override is Enterprise-only). Move the plan to **B1 (Linux)** first: about **AUD 0.027/hour, roughly AUD 20/month**.

1. `./scripts/provision.sh --stage prod --github-owner JRC-Software --sku B1 --canonical-host groove.com.au --alert-email <…>`. This also turns on Always On, removes the 60 CPU-min/day quota and adds a 99.95% SLA. `--canonical-host` makes `www` 301 to the apex.
2. `./scripts/bind-custom-domains.sh --dns` prints the records.
3. In Cloudflare, lower the TTL on existing records a day ahead, then create or replace `A @`, `TXT asuid`, `CNAME www` and `TXT asuid.www`. Set them to **DNS only (grey cloud)** and leave MX/SPF/DKIM alone.
4. `./scripts/bind-custom-domains.sh --bind` adds the hostnames and free managed certificates.
5. Set the repo variable `PROD_SITE_URL=https://groove.com.au`.

**Why grey cloud?** Azure's free managed certificates validate and renew over the public DNS/HTTP path, and the Cloudflare proxy gets in the way. For Cloudflare WAF/caching later, upload a Cloudflare Origin CA certificate to the app first, then switch to orange cloud with SSL mode **Full (strict)**.

## 7. Changing things later

| Change | How |
|---|---|
| Plan size | `provision.sh --stage prod --sku B2` (or `S1` for deployment slots) |
| Developers add a build step | They add `package.json` with `npm run build`; set repo variable `SITE_DIR` to the output folder (e.g. `dist`) |
| Prod app settings | Add to `prodAppSettings` in `infra/main.bicep` and re-run `provision.sh`. **Settings added only in the portal are removed on the next run** |
| Lock the dev site to the team | Cloudflare Zero Trust → Access → protect the `workers.dev` hostname (free up to 50 users) |
| Rotate the Cloudflare token | Create a new token, re-run `configure-github.sh --stage dev`, delete the old token |

## 8. Troubleshooting

| Symptom | Cause / fix |
|---|---|
| `'.' is not recognized as an internal or external command` | You're in Windows Command Prompt. Run the scripts in Azure Cloud Shell → Bash. |
| *Deploy dev*: `Authentication error` / `10000` | Wrong or expired `CLOUDFLARE_API_TOKEN`, or token not scoped to the account in `CLOUDFLARE_ACCOUNT_ID`. |
| *Deploy dev*: "You need a workers.dev subdomain" | Open Workers & Pages in the dashboard once and pick a subdomain. |
| No *Run workflow* button on *Deploy prod* | `deploy-prod.yml` isn't on the default branch (`dev`) yet. |
| *Deploy prod* jobs skipped | It was run from a branch other than `prod`. |
| "… is not allowed to deploy to prod" | The person isn't in `PROD_DEPLOYERS`. An admin adds them under Settings → Variables. |
| CI: "Broken local references" | A page points at a file that isn't in the repo (often letter case). |
| `AADSTS700213: No matching federated identity record` | Compare the subject in the error with `prodOidcSubject` in `.provision-outputs.json`; re-run `provision.sh --stage prod` (or pass `--subject-prefix`). |
| Prod returns **403 – site stopped** | F1 daily CPU quota hit. It resets daily; move to B1. |
| `Exceeded the limit of 1 free tier linux server farm` | Another Free Linux plan exists in the subscription. Use `--sku B1`. |

## 9. Reference

- Workflows: `.github/workflows/ci.yml`, `deploy-dev.yml` (Cloudflare, auto), `deploy-prod.yml` (Azure, manual)
- Build helpers: `.github/deploy/package-site.sh`, `check-links.mjs`, `prepare-cloudflare-dev.sh`, `server.js` (+ `server.test.js`)
- Azure IaC: `infra/main.bicep` (+ `modules/`), `infra/main.bicepparam`
- Scripts: `scripts/provision.sh`, `scripts/configure-github.sh`, `scripts/bind-custom-domains.sh`
