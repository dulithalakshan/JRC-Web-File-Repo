#!/usr/bin/env bash
# -----------------------------------------------------------------------------
# Go-live helper for groove.com.au (Cloudflare DNS -> Azure App Service).
#
#   ./scripts/bind-custom-domains.sh --dns     # 1. print the Cloudflare records to create
#   ./scripts/bind-custom-domains.sh --bind    # 2. bind groove.com.au + www with free managed TLS certs
#
# Prod only. The dev site lives on Cloudflare Workers (*.workers.dev) and needs no DNS.
#
# Requires the plan to be Basic (B1) or higher - Free (F1) cannot use custom domains.
#   Upgrade first:  ./scripts/provision.sh --github-owner <org> --sku B1
# Create the Cloudflare records as "DNS only" (grey cloud) so Azure can issue
# and renew the managed certificates.
# -----------------------------------------------------------------------------
set -euo pipefail

DOMAIN="${DOMAIN:-groove.com.au}"
MODE=""

usage() {
  awk 'NR == 1 { next } /^#/ { sub(/^# ?/, ""); print; next } { exit }' "$0"
  exit "${1:-0}"
}

while [[ $# -gt 0 ]]; do
  case "$1" in
    --dns)  MODE="dns"; shift ;;
    --bind) MODE="bind"; shift ;;
    -h|--help) usage 0 ;;
    *) echo "Unknown option: $1" >&2; usage 1 ;;
  esac
done

die() { echo "ERROR: $*" >&2; exit 1; }

[[ -n "$MODE" ]] || usage 1

REPO_ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
OUTPUT_FILE="$REPO_ROOT/.provision-outputs.json"
[[ -f "$OUTPUT_FILE" ]] || die "$OUTPUT_FILE not found. Run ./scripts/provision.sh first."
command -v az >/dev/null || die "Azure CLI (az) not found."
command -v jq >/dev/null || die "jq not found."
o() { jq -r ".$1 // \"\"" "$OUTPUT_FILE"; }

az account set --subscription "$(o subscriptionId)"
RG="$(o resourceGroup)"
PLAN="$(o planName)"
PROD_APP="$(o prodAppName)"
VERIFY_ID="$(o customDomainVerificationId)"
[[ -n "$PROD_APP" ]] || die "No prod app in $OUTPUT_FILE. Run: ./scripts/provision.sh --stage prod ..."

tier="$(az appservice plan show -g "$RG" -n "$PLAN" --query sku.tier -o tsv)"
if [[ "$tier" == "Free" || "$tier" == "Shared" ]]; then
  die "Plan $PLAN is on the $tier tier, which cannot use custom domains.
       Upgrade first: ./scripts/provision.sh --github-owner <org> --sku B1"
fi

# --- 1. DNS records -----------------------------------------------------------
if [[ "$MODE" == "dns" ]]; then
  prod_ip="$(az webapp config hostname get-external-ip -g "$RG" --webapp-name "$PROD_APP" --query ip -o tsv)"
  echo
  echo "Create these records in Cloudflare (zone: $DOMAIN). Proxy status: DNS only (grey cloud)."
  echo "Lower the TTL on any existing @ / www records a day before cut-over."
  echo
  row() { printf '  %-6s %-15s %-60s %s\n' "$@"; }
  row Type  Name           Content                        Proxy
  row ----- -------------- ------------------------------ --------
  row A     @              "$prod_ip"                     "DNS only"
  row TXT   asuid          "$VERIFY_ID"                   ""
  row CNAME www            "$(o prodDefaultHostname)"     "DNS only"
  row TXT   asuid.www      "$VERIFY_ID"                   ""
  echo
  echo "Leave existing MX / SPF / DKIM / other TXT records untouched."
  echo "When the records resolve (dig +short $DOMAIN), run: $0 --bind"
  exit 0
fi

# --- 2. Bind hostnames + managed certificates --------------------------------
cert_thumbprint() {
  az webapp config ssl list -g "$RG" \
    --query "[?contains(hostNames, '$1')].thumbprint | [0]" -o tsv 2>/dev/null || true
}

bind_host() {
  local app="$1" host="$2" thumb
  echo "==> $host -> $app"

  if az webapp config hostname list -g "$RG" --webapp-name "$app" --query "[].name" -o tsv | grep -qx "$host"; then
    echo "    hostname already added"
  else
    az webapp config hostname add -g "$RG" --webapp-name "$app" --hostname "$host" -o none \
      || die "Could not add $host. Check the Cloudflare records (and that they are DNS only), then re-run."
  fi

  thumb="$(cert_thumbprint "$host")"
  if [[ -z "$thumb" ]]; then
    echo "    creating free managed certificate (can take several minutes)"
    # The CLI may return before issuance finishes, so read the thumbprint back by polling.
    az webapp config ssl create -g "$RG" -n "$app" --hostname "$host" -o none
    for _ in $(seq 1 40); do
      thumb="$(cert_thumbprint "$host")"
      [[ -n "$thumb" ]] && break
      sleep 15
    done
    [[ -n "$thumb" ]] || die "Certificate for $host not issued after 10 minutes. Check the app's
       Certificates blade in the portal, then re-run this script (it resumes)."
  else
    echo "    certificate exists"
  fi

  az webapp config ssl bind -g "$RG" -n "$app" --hostname "$host" \
    --certificate-thumbprint "$thumb" --ssl-type SNI -o none
  echo "    https://$host bound (SNI)"
}

bind_host "$PROD_APP" "$DOMAIN"
bind_host "$PROD_APP" "www.$DOMAIN"

cat <<EOF

==> Done. Last steps (GitHub > Settings > Secrets and variables > Actions > Variables):
    PROD_SITE_URL    = https://$DOMAIN
EOF
