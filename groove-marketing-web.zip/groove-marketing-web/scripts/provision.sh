#!/usr/bin/env bash
# -----------------------------------------------------------------------------
# Provision / update the Groove PROD infrastructure on Azure (dev is on Cloudflare).
# Run from Azure Cloud Shell (Bash): it has az, bicep, gh and jq.
# (Windows Command Prompt / PowerShell can't run .sh files.)
#
#   ./scripts/provision.sh --stage shared [--what-if]
#   ./scripts/provision.sh --stage prod --github-owner <org> [--sku F1|B1|...]
#                          [--alert-email x@y] [--canonical-host groove.com.au] [--what-if]
#
#   --stage shared  Log Analytics + App Service plan (no GitHub needed)
#   --stage prod    + prod web app, App Insights, GitHub deploy identity, alerting
#
# For prod the GitHub repo is read with gh to build its OIDC subject
# (or pass --subject-prefix yourself).
# Safe to re-run. Re-run with --sku B1 to upgrade before go-live.
# Writes .provision-outputs.json (used by configure-github.sh / bind-custom-domains.sh).
# -----------------------------------------------------------------------------
set -euo pipefail

SUBSCRIPTION_ID="${SUBSCRIPTION_ID:-0dbd7b35-50c0-4303-8aed-1a417aaf7b9e}"
RESOURCE_GROUP="${RESOURCE_GROUP:-prod-groove-marketingweb-rg-aue}"
EXPECTED_LOCATION="australiaeast"
GITHUB_OWNER="${GITHUB_OWNER:-}"
export GITHUB_REPO="${GITHUB_REPO:-groove-marketing-web}"
export GITHUB_SUBJECT_PREFIX="${GITHUB_SUBJECT_PREFIX:-}"
export PLAN_SKU="${PLAN_SKU:-F1}"
export LINUX_FX_VERSION="${LINUX_FX_VERSION:-NODE|24-lts}"
export ALERT_EMAIL="${ALERT_EMAIL:-}"
export PROD_CANONICAL_HOST="${PROD_CANONICAL_HOST:-}"
export STAGE="${STAGE:-prod}"
WHAT_IF=false
# GitHub switched new repos to ID-based ("immutable") OIDC subjects on this date.
IMMUTABLE_SUBJECT_SINCE="2026-07-15"

usage() {
  awk 'NR == 1 { next } /^#/ { sub(/^# ?/, ""); print; next } { exit }' "$0"
  exit "${1:-0}"
}

while [[ $# -gt 0 ]]; do
  case "$1" in
    --stage)          STAGE="$2"; shift 2 ;;
    --github-owner)   GITHUB_OWNER="$2"; shift 2 ;;
    --github-repo)    GITHUB_REPO="$2"; shift 2 ;;
    --subject-prefix) GITHUB_SUBJECT_PREFIX="$2"; shift 2 ;;
    --sku)            PLAN_SKU="$2"; shift 2 ;;
    --runtime)        LINUX_FX_VERSION="$2"; shift 2 ;;
    --alert-email)    ALERT_EMAIL="$2"; shift 2 ;;
    --canonical-host) PROD_CANONICAL_HOST="$2"; shift 2 ;;
    --subscription)   SUBSCRIPTION_ID="$2"; shift 2 ;;
    --resource-group) RESOURCE_GROUP="$2"; shift 2 ;;
    --what-if)        WHAT_IF=true; shift ;;
    -h|--help)        usage 0 ;;
    *) echo "Unknown option: $1" >&2; usage 1 ;;
  esac
done

REPO_ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
PARAM_FILE="$REPO_ROOT/infra/main.bicepparam"
OUTPUT_FILE="$REPO_ROOT/.provision-outputs.json"

die() { echo "ERROR: $*" >&2; exit 1; }

command -v az >/dev/null || die "Azure CLI (az) not found. Use Azure Cloud Shell or install az."
command -v jq >/dev/null || die "jq not found."
[[ "$STAGE" =~ ^(shared|prod)$ ]] || die "--stage must be shared or prod."

# --- GitHub OIDC subject -------------------------------------------------------
# Repos created on/after 2026-07-15, or opted in at repo/org level, use
#   repo:OWNER@OWNER_ID/REPO@REPO_ID   otherwise   repo:OWNER/REPO
if [[ "$STAGE" == "prod" && -z "$GITHUB_SUBJECT_PREFIX" ]]; then
  [[ -n "$GITHUB_OWNER" ]] || die "--github-owner is required (the GitHub org that owns $GITHUB_REPO)."
  command -v gh >/dev/null || die "gh CLI not found. Install it, or pass --subject-prefix."
  gh auth status >/dev/null 2>&1 || die "gh is not logged in. Run: gh auth login -s repo,workflow,admin:org"

  echo "==> Reading GitHub repo $GITHUB_OWNER/$GITHUB_REPO"
  repo_json="$(gh api "repos/$GITHUB_OWNER/$GITHUB_REPO" 2>/dev/null)" \
    || die "Repo $GITHUB_OWNER/$GITHUB_REPO not found. Create it first:
    gh repo create $GITHUB_OWNER/$GITHUB_REPO --private"
  owner_login="$(jq -r .owner.login <<<"$repo_json")"
  owner_id="$(jq -r .owner.id <<<"$repo_json")"
  repo_name="$(jq -r .name <<<"$repo_json")"
  repo_id="$(jq -r .id <<<"$repo_json")"
  created_at="$(jq -r .created_at <<<"$repo_json")"

  repo_optin="$(gh api "repos/$owner_login/$repo_name/actions/oidc/customization/sub" \
    --jq '.use_immutable_subject // false' 2>/dev/null || echo false)"
  org_optin="$(gh api "orgs/$owner_login/actions/oidc/customization/sub" \
    --jq '.use_immutable_subject // false' 2>/dev/null || echo false)"

  if [[ "$created_at" > "$IMMUTABLE_SUBJECT_SINCE" || "$repo_optin" == "true" || "$org_optin" == "true" ]]; then
    GITHUB_SUBJECT_PREFIX="repo:${owner_login}@${owner_id}/${repo_name}@${repo_id}"
  else
    GITHUB_SUBJECT_PREFIX="repo:${owner_login}/${repo_name}"
  fi
  GITHUB_REPO="$repo_name"
fi
if [[ "$STAGE" == "prod" ]]; then
  [[ "$GITHUB_SUBJECT_PREFIX" == repo:* ]] || die "Subject prefix must start with 'repo:' (got '$GITHUB_SUBJECT_PREFIX')."
fi

# --- Azure -----------------------------------------------------------------------
echo "==> Checking Azure login"
az account show >/dev/null 2>&1 || die "Not logged in. Run: az login"
az account set --subscription "$SUBSCRIPTION_ID"
echo "    Subscription: $(az account show --query name -o tsv) ($SUBSCRIPTION_ID)"

echo "==> Checking resource group $RESOURCE_GROUP"
rg_location="$(az group show --name "$RESOURCE_GROUP" --query location -o tsv 2>/dev/null)" \
  || die "Resource group $RESOURCE_GROUP not found. Create it first:
    az group create -n $RESOURCE_GROUP -l $EXPECTED_LOCATION"
[[ "$rg_location" == "$EXPECTED_LOCATION" ]] \
  || die "$RESOURCE_GROUP is in '$rg_location', expected '$EXPECTED_LOCATION'."

echo "==> Checking resource providers"
for ns in Microsoft.Web Microsoft.Insights Microsoft.OperationalInsights \
          Microsoft.ManagedIdentity Microsoft.AlertsManagement; do
  state="$(az provider show --namespace "$ns" --query registrationState -o tsv 2>/dev/null || echo Unknown)"
  if [[ "$state" != "Registered" ]]; then
    echo "    registering $ns (needs Contributor at subscription scope)"
    az provider register --namespace "$ns" --wait --only-show-errors >/dev/null
  fi
done

echo "==> Parameters"
printf '    %-14s %s\n' \
  "Stage"         "$STAGE" \
  "OIDC subject"  "${GITHUB_SUBJECT_PREFIX:-<not needed>}${GITHUB_SUBJECT_PREFIX:+:environment:prod}" \
  "Plan SKU"      "$PLAN_SKU" \
  "Runtime"       "$LINUX_FX_VERSION" \
  "Alert email"   "${ALERT_EMAIL:-<none>}" \
  "Prod canonical" "${PROD_CANONICAL_HOST:-<none>}"

if [[ "$PLAN_SKU" == "F1" ]]; then
  cat <<'EOF'
    NOTE: F1 (Free) = no custom domains/SSL, no Always On, 60 CPU-min/day per app, no SLA.
          Fine for build-out. Re-run with --sku B1 before pointing groove.com.au at it.
EOF
fi

DEPLOYMENT_NAME="groove-marketingweb-$STAGE-$(date -u +%Y%m%d-%H%M%S)"

if $WHAT_IF; then
  echo "==> What-if (no changes will be made)"
  az deployment group what-if \
    --resource-group "$RESOURCE_GROUP" \
    --name "$DEPLOYMENT_NAME" \
    --parameters "$PARAM_FILE"
  exit 0
fi

echo "==> Deploying $DEPLOYMENT_NAME (takes 2-4 minutes)"
new_outputs="$(az deployment group create \
  --resource-group "$RESOURCE_GROUP" \
  --name "$DEPLOYMENT_NAME" \
  --parameters "$PARAM_FILE" \
  --query 'properties.outputs' \
  --output json | jq 'with_entries(.value = .value.value)')"

# Merge with earlier stages: keep values this stage didn't produce.
if [[ -f "$OUTPUT_FILE" ]]; then
  jq -s '.[0] * (.[1] | with_entries(select(.value != "")))' "$OUTPUT_FILE" - <<<"$new_outputs" > "$OUTPUT_FILE.tmp"
  mv "$OUTPUT_FILE.tmp" "$OUTPUT_FILE"
else
  printf '%s\n' "$new_outputs" > "$OUTPUT_FILE"
fi

o() { jq -r ".$1 // \"\"" "$OUTPUT_FILE"; }
line() { [[ -n "$2" ]] && printf '  %-13s %s\n' "$1" "$2"; return 0; }

echo
echo "==> Done ($STAGE). Outputs saved to .provision-outputs.json"
echo
line "Plan"        "$(o planName) ($(o planSku))"
prod_host="$(o prodDefaultHostname)"
line "Workspace"   "$(o logWorkspaceName)"
line "prod site"   "${prod_host:+https://$prod_host}"
line "OIDC trusts" "$(o prodOidcSubject)"
if [[ -n "$(o prodClientId)" ]]; then
  echo
  echo "  'prod' environment secrets (configure-github.sh --stage prod sets these):"
  line "  prod"      "AZURE_CLIENT_ID       = $(o prodClientId)"
  line "  prod"      "AZURE_TENANT_ID       = $(o tenantId)"
  line "  prod"      "AZURE_SUBSCRIPTION_ID = $(o subscriptionId)"
fi
echo
