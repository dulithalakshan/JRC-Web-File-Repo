#!/usr/bin/env bash
# -----------------------------------------------------------------------------
# Configure GitHub for groove-marketing-web. Run once per stage:
#
#   ./scripts/configure-github.sh --stage dev  --owner <org> --cf-account-id <id> [--dev-team <slug>] [--it-team <slug>]
#   ./scripts/configure-github.sh --stage prod --owner <org> --it-team <slug> [--prod-deployers a,b] [--prod-approval]
#
#   --stage dev       "dev" environment (deploys only from the dev branch) with the
#                     Cloudflare secrets; dev = default branch; dev protected from
#                     force-push/delete. Needs nothing from Azure.
#                     The Cloudflare API token is read from $CLOUDFLARE_API_TOKEN,
#                     or prompted for (never shown, never passed on the command line).
#   --stage prod      "prod" environment (deploys only from the prod branch) with the
#                     Azure secrets; PROD_DEPLOYERS; prod branch protection.
#                     Needs .provision-outputs.json from: provision.sh --stage prod
#   --it-team         GitHub team allowed to merge into "prod" (IT Operations)
#   --dev-team        GitHub team of developers (gets write access; works on "dev")
#   --prod-deployers  Comma-separated GitHub logins allowed to run/re-run the manual
#                     prod deploy (default: you)
#   --prod-approval   Also require an IT team approval on each prod deploy
#                     (private repos: GitHub Enterprise only)
#
# Needs: repo admin rights; gh logged in with scopes repo, workflow, admin:org.
# Private repos need GitHub Team/Pro/Enterprise for environments + branch protection.
# Safe to re-run.
# -----------------------------------------------------------------------------
set -euo pipefail

STAGE=""
OWNER=""
REPO="groove-marketing-web"
IT_TEAM=""
DEV_TEAM=""
CF_ACCOUNT_ID="${CLOUDFLARE_ACCOUNT_ID:-}"
PROD_APPROVAL=false
PROD_DEPLOYERS=""

usage() {
  awk 'NR == 1 { next } /^#/ { sub(/^# ?/, ""); print; next } { exit }' "$0"
  exit "${1:-0}"
}

while [[ $# -gt 0 ]]; do
  case "$1" in
    --stage)          STAGE="$2"; shift 2 ;;
    --owner)          OWNER="$2"; shift 2 ;;
    --repo)           REPO="$2"; shift 2 ;;
    --it-team)        IT_TEAM="$2"; shift 2 ;;
    --dev-team)       DEV_TEAM="$2"; shift 2 ;;
    --cf-account-id)  CF_ACCOUNT_ID="$2"; shift 2 ;;
    --prod-deployers) PROD_DEPLOYERS="$2"; shift 2 ;;
    --prod-approval)  PROD_APPROVAL=true; shift ;;
    -h|--help)        usage 0 ;;
    *) echo "Unknown option: $1" >&2; usage 1 ;;
  esac
done

REPO_ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
OUTPUT_FILE="$REPO_ROOT/.provision-outputs.json"
FULL="$OWNER/$REPO"

die()  { echo "ERROR: $*" >&2; exit 1; }
warn() { echo "WARN:  $*" >&2; }
step() { echo "==> $*"; }
o()    { jq -r ".$1 // \"\"" "$OUTPUT_FILE"; }

[[ "$STAGE" =~ ^(dev|prod)$ ]] || die "--stage dev or --stage prod is required."
[[ -n "$OWNER" ]] || die "--owner is required."
command -v gh >/dev/null || die "GitHub CLI (gh) not found."
command -v jq >/dev/null || die "jq not found."
gh auth status >/dev/null 2>&1 || die "gh is not logged in. Run: gh auth login -s repo,workflow,admin:org"
gh repo view "$FULL" >/dev/null 2>&1 || die "Repo $FULL not found (or no access)."

if [[ "$STAGE" == "dev" ]]; then
  [[ -n "$CF_ACCOUNT_ID" ]] || die "--cf-account-id is required (Cloudflare dashboard > Workers & Pages > Account ID)."
else
  [[ -f "$OUTPUT_FILE" && -n "$(o prodClientId)" ]] \
    || die "No prod identity in $OUTPUT_FILE. Run first: ./scripts/provision.sh --stage prod --github-owner $OWNER"
  [[ -n "$IT_TEAM" ]] || warn "No --it-team: anyone with write access could merge into prod. Strongly recommended."
  $PROD_APPROVAL && [[ -z "$IT_TEAM" ]] && die "--prod-approval needs --it-team."
fi

# --- Common: repo settings, team access, default branch -----------------------
step "Repository $FULL"
gh repo edit "$FULL" --enable-merge-commit >/dev/null
if [[ -n "$IT_TEAM" ]]; then
  gh api -X PUT "orgs/$OWNER/teams/$IT_TEAM/repos/$FULL" -f permission=maintain >/dev/null
  echo "    team $IT_TEAM -> maintain"
fi
if [[ -n "$DEV_TEAM" ]]; then
  gh api -X PUT "orgs/$OWNER/teams/$DEV_TEAM/repos/$FULL" -f permission=push >/dev/null
  echo "    team $DEV_TEAM -> write"
fi
branches="$(gh api "repos/$FULL/branches" --jq '.[].name')"
for b in dev prod; do
  grep -qx "$b" <<<"$branches" || die "Branch '$b' doesn't exist in $FULL."
done
gh repo edit "$FULL" --default-branch dev >/dev/null
echo "    default branch -> dev"

# Create/update an environment that only one branch may deploy from.
make_env() {
  local env="$1" branch="$2" reviewers="${3:-[]}"
  step "Environment '$env' (deploys only from branch '$branch')"
  local base='{"deployment_branch_policy":{"protected_branches":false,"custom_branch_policies":true}}'
  local body="$base"
  [[ "$reviewers" != "[]" ]] && body="$(jq -c --argjson r "$reviewers" '. + {reviewers: $r}' <<<"$base")"
  if ! gh api -X PUT "repos/$FULL/environments/$env" --input - <<<"$body" >/dev/null 2>&1; then
    [[ "$body" == "$base" ]] && die "Could not create environment '$env' (private repos need GitHub Team/Pro/Enterprise)."
    warn "Required reviewers aren't available on this plan - creating '$env' without them."
    gh api -X PUT "repos/$FULL/environments/$env" --input - <<<"$base" >/dev/null \
      || die "Could not create environment '$env' (private repos need GitHub Team/Pro/Enterprise)."
  fi
  if ! gh api "repos/$FULL/environments/$env/deployment-branch-policies" --jq '.branch_policies[].name' | grep -qx "$branch"; then
    gh api -X POST "repos/$FULL/environments/$env/deployment-branch-policies" -f name="$branch" -f type=branch >/dev/null
  fi
}

protect() {
  local branch="$1" body="$2"
  gh api -X PUT "repos/$FULL/branches/$branch/protection" --input - <<<"$body" >/dev/null \
    || warn "Could not protect '$branch' (private repos need GitHub Team/Pro/Enterprise)."
}

# --- Stage: dev (Cloudflare Workers) -------------------------------------------
if [[ "$STAGE" == "dev" ]]; then
  make_env dev dev

  step "Cloudflare secrets in environment 'dev'"
  if [[ -z "${CLOUDFLARE_API_TOKEN:-}" ]]; then
    read -rsp "    Paste the Cloudflare API token (input hidden): " CLOUDFLARE_API_TOKEN
    echo
  fi
  [[ -n "$CLOUDFLARE_API_TOKEN" ]] || die "Empty Cloudflare API token."
  printf '%s' "$CLOUDFLARE_API_TOKEN" | gh secret set CLOUDFLARE_API_TOKEN --repo "$FULL" --env dev
  printf '%s' "$CF_ACCOUNT_ID"        | gh secret set CLOUDFLARE_ACCOUNT_ID --repo "$FULL" --env dev
  unset CLOUDFLARE_API_TOKEN

  step "Protect 'dev' (no force-push / deletion)"
  protect dev '{"required_status_checks":null,"enforce_admins":false,"required_pull_request_reviews":null,"restrictions":null,"allow_force_pushes":false,"allow_deletions":false}'

  cat <<EOF

==> Dev configured: https://github.com/$FULL/settings/environments
    Next: commit the pipeline files to 'dev' and push - "Deploy dev" publishes to
    https://groove-marketing-web-dev.<your-subdomain>.workers.dev
EOF
  exit 0
fi

# --- Stage: prod (Azure App Service) -------------------------------------------
reviewers="[]"
if $PROD_APPROVAL; then
  reviewers="[{\"type\":\"Team\",\"id\":$(gh api "orgs/$OWNER/teams/$IT_TEAM" --jq .id)}]"
fi
make_env prod prod "$reviewers"

step "Azure secrets in environment 'prod'"
printf '%s' "$(o prodClientId)"   | gh secret set AZURE_CLIENT_ID       --repo "$FULL" --env prod
printf '%s' "$(o tenantId)"       | gh secret set AZURE_TENANT_ID       --repo "$FULL" --env prod
printf '%s' "$(o subscriptionId)" | gh secret set AZURE_SUBSCRIPTION_ID --repo "$FULL" --env prod

[[ -n "$PROD_DEPLOYERS" ]] || PROD_DEPLOYERS="$(gh api user --jq .login)"
step "PROD_DEPLOYERS = $PROD_DEPLOYERS"
gh variable set PROD_DEPLOYERS --repo "$FULL" --body "$PROD_DEPLOYERS"

step "Protect 'prod' (PR + passing CI; only ${IT_TEAM:-admins/maintainers} can merge)"
restrictions="null"
[[ -n "$IT_TEAM" ]] && restrictions="{\"users\":[],\"teams\":[\"$IT_TEAM\"],\"apps\":[]}"
protect prod "$(cat <<EOF
{
  "required_status_checks": { "strict": false, "checks": [ { "context": "ci" } ] },
  "enforce_admins": true,
  "required_pull_request_reviews": { "required_approving_review_count": 0, "dismiss_stale_reviews": true },
  "restrictions": $restrictions,
  "allow_force_pushes": false,
  "allow_deletions": false,
  "required_conversation_resolution": true
}
EOF
)"

cat <<EOF

==> Prod configured: https://github.com/$FULL/settings/environments
    Release = PR 'dev' -> 'prod' -> CI passes -> IT merges (merge commit)
              -> Actions > Deploy prod > Run workflow (branch: prod)$($PROD_APPROVAL && echo " -> IT approves")
    Only $PROD_DEPLOYERS can run or re-run prod deploys
    (change: Settings > Secrets and variables > Actions > Variables > PROD_DEPLOYERS).
EOF
